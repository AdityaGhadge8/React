interface Currency {
    name: string;
    value: number;
    flag: string;
    symbol: string;
}