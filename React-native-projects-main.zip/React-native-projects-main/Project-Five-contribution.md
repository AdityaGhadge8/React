[Create Fun and Simple Dice APP](https://settysantu.hashnode.dev/create-a-fun-and-simple-dice-app-with-react-native-a-beginners-tutorial)
